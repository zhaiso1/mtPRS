## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(mtPRS)

## ----eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE-----------------------
## Simulate data for PGx GWAS mtPRS analysis

dat <- generate_pgx_data(structure = "clustered",
                         sparseness = "more",
                         rho_DT = c(0.5,0.5,0.5,0.5),
                         rho_T = 0.5,
                         rho_E = 0.3,
                         rho_C = 0.1,
                         K=4,
                         m=1000,
                         pcausal=0.1,
                         blocksize=100,
                         gamma = 1,
                         samplesize=700,
                         h2_base=0.3,
                         h2_target=0.3)

## ---- eval=TRUE, echo=TRUE----------------------------------------------------
re <- mtPRS_PCA(dat, pcut = 0.05, varcut = 0.8, K = 4, phenotype = "pgx")

hist(re$mtPRS)

## ---- eval=TRUE, echo=TRUE----------------------------------------------------
re <- mtPRS_O(dat, pcut = 0.05, varcut = 0.8, K = 4, phenotype = "pgx")

print(re)

